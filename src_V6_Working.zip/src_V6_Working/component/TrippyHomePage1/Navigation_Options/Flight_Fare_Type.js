import React from "react";
import "./Flight_Fare_Type.css";

export default function Flight_Fare_Type() {
  const classTypes = [
    { text: "Economy", value: 1 },
    { text: "Business", value: 2 },
    { text: "First", value: 3 },
  ];

  return (
    <div className="flight_fare_type_container">
      <div className="wrap_div">
        <div className="text">
          Select a <br /> class type:
        </div>
        <div className="flight_fare_type_radio-buttons">
          {classTypes.map((classType, idx) => (
            <label key={idx}>
              <input type="radio" name="classType" value={classType.value} />
              <b><h6>{classType.text} <br />
              class</h6></b>
            </label>
          ))}
        </div>
      </div>

      <div className="flight_trending_flight">
        <div className="text">
          Trending <br />
          Searches:
        </div>
        <button className="flight_trending_flight_button">Mumbai - Pune</button>
      </div>
    </div>
  );
}

import React from "react";
import Flight_Page2 from "./Flight_Page2";
import './Flight_Details.css'

export default function Flight_Details() {
  return (
    <div className="flight_component_container">
      <Flight_Page2 />
    </div>
  );
}
